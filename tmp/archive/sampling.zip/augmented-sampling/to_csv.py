import numpy as np
import csv

fields = ['Group', 'Type', 'Name']

def get_transformation(name):
    print(name.split("_"))
    name_arr = name.split("_")
    if len(name_arr) == 2:
        name_arr.insert(0,"Original")
    return f"{name_arr[0]}_{name_arr[1]}"

with open("augmented_text.txt", "r") as f:
    files = f.read().splitlines()
    for i in range(len(files)):
        # Remove Flash-No-Flash from line and convert to list 
        files[i] = files[i].replace('Augmented-Lettuce-Dataset','').split("\\")
        files[i].pop(0)
        # Create Group/Stratum (Class_Type): {FN_Flash, FN_No Flash, -K_Flash, -K_No Flash, -N_Flash, -N_No Flash}
        grp = get_transformation(files[i][1])
        files[i].insert(0,f'{files[i][0]}_{grp}') 
        print(files[0])

# Write to CSV File
with open('augmented.csv', 'w',newline='', encoding='utf-8') as f:
    write = csv.writer(f, quoting=csv.QUOTE_NONE)
    # writes the fields 
    write.writerow(fields)
    # writes the modified content to file
    write.writerows(files)
