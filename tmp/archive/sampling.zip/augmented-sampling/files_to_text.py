import os


path ="train-images-augmented"

filelist = []

for root, dirs, files in os.walk(path):
    for file in files:
        filelist.append(os.path.join(root,file))

with open("strat_text.txt","w") as file:
    for name in filelist:
        file.write(name)
        file.write('\n')